import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { Sparkles } from 'lucide-react';

export default function ConsultLogForm({ student, teacherId }) {
  const { addRequest, teachers, consultDrafts, updateConsultDraft } = useStore();
  
  const currentDate = new Date();
  const days = ['일', '월', '화', '수', '목', '금', '토'];
  const formattedDate = `${currentDate.getFullYear()}. ${String(currentDate.getMonth() + 1).padStart(2, '0')}. ${String(currentDate.getDate()).padStart(2, '0')} (${days[currentDate.getDay()]})`;

  const [learningContent, setLearningContent] = useState('');
  
  const consultContent = consultDrafts[student.id] || `[${formattedDate}]\n`;
  const setConsultContent = (val) => updateConsultDraft(student.id, val);
  
  const teacher = teachers.find(t => t.id === teacherId);
  const subject = teacher?.subject || '';

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!consultContent.trim() && !learningContent.trim()) return;
    
    const combinedContent = `[오늘의 학습내용]\n${learningContent}\n\n[오늘의 상담일지]\n${consultContent}`;

    addRequest({
      teacherId,
      studentId: student.id,
      studentName: student.name,
      type: 'consult',
      content: combinedContent,
      status: '대기'
    });
    
    setConsultContent('');
    setLearningContent('');
  };

  const handleDelete = () => {
    setConsultContent('');
    setLearningContent('');
  };

  const generateAILearningContent = () => {
    if (!learningContent.trim()) {
      alert("다듬을 내용을 먼저 간단히 입력해주세요. (예: 기초 연산 했음, 덧셈 틀린거 정리)");
      return;
    }

    let transformed = learningContent
      .replace(/오늘/g, "금일")
      .replace(/잘함|잘했음|잘함\./g, "우수하게 수행.")
      .replace(/못함|부족함/g, "보완 필요.")
      .replace(/했음/g, "완료.")
      .replace(/안함|안했음/g, "미흡.")
      .replace(/틀린거|틀린것/g, "오답")
      .replace(/숙제/g, "과제물")
      .replace(/진도/g, "학습 진도");

    // 불필요한 자동 마무리를 제거하고 깔끔하게 점(.)으로만 끝맺음
    transformed = transformed.trim();
    if (!transformed.endsWith('.') && !transformed.endsWith('다') && !transformed.endsWith('함') && !transformed.endsWith('음')) {
      transformed += ".";
    }

    // 글자수 제한 해제 (기존 자르기 로직 제거)
    setLearningContent(transformed);
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col h-full space-y-4">
      {/* 오늘의 학습내용 영역 */}
      <div className="flex flex-col flex-1">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-bold text-gray-700 flex items-center">
            오늘의 학습내용
          </span>
          <button 
            type="button" 
            onClick={generateAILearningContent}
            className="flex items-center space-x-1 text-xs font-bold text-brand-600 bg-brand-50 hover:bg-brand-100 px-3 py-1.5 rounded-lg transition-all border border-brand-200"
          >
            <Sparkles size={14} />
            <span>✨ AI 학습내용 자동완성</span>
          </button>
        </div>
        <textarea
          value={learningContent}
          onChange={(e) => setLearningContent(e.target.value)}
          className="w-full flex-1 px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition-all min-h-[140px] resize-none text-sm leading-relaxed"
          placeholder={`오늘 ${student.name} 학생이 수업에서 배운 내용이나 진도를 입력해주세요...`}
        />
      </div>

      {/* 오늘의 상담일지 영역 */}
      <div className="flex flex-col flex-1 mt-2">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm font-bold text-gray-700">오늘의 상담일지 (출결 연동)</span>
        </div>
        <textarea
          value={consultContent}
          onChange={(e) => setConsultContent(e.target.value)}
          className="w-full flex-1 px-4 py-3 rounded-xl border border-brand-100 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition-all min-h-[100px] resize-none text-sm leading-relaxed bg-brand-50/30"
          placeholder="좌측 타임라인에서 [출석], [지각] 등을 누르면 자동으로 시간이 기입됩니다."
        />
      </div>

      <div className="flex space-x-3 pt-2">
        <button 
          type="button" 
          onClick={handleDelete}
          className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-3 px-4 rounded-xl transition-all"
        >
          초기화
        </button>
        <button 
          type="submit" 
          className="flex-[2] bg-brand-600 hover:bg-brand-700 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-md shadow-brand-500/20"
        >
          결재승인
        </button>
      </div>
    </form>
  );
}
