import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { X, Check } from 'lucide-react';

export default function AddStudentModal({ isOpen, onClose, teacherId }) {
  const { addStudent, teachers } = useStore();
  const teacher = teachers.find(t => t.id === teacherId);

  const [formData, setFormData] = useState({
    name: '',
    school: '',
    grade: '초1',
    phone: '',
    schedules: {} // e.g. { '월': '14:00', '수': '15:30' }
  });

  const DAYS = ['월', '화', '수', '목', '금', '토', '일'];
  const GRADES = [
    '초1', '초2', '초3', '초4', '초5', '초6',
    '중1', '중2', '중3',
    '고1', '고2', '고3'
  ];

  if (!isOpen) return null;

  const toggleDay = (day) => {
    setFormData(prev => {
      const newSchedules = { ...prev.schedules };
      if (newSchedules[day]) {
        delete newSchedules[day];
      } else {
        newSchedules[day] = '14:00';
      }
      return { ...prev, schedules: newSchedules };
    });
  };

  const handleTimeChange = (day, time) => {
    setFormData(prev => ({
      ...prev,
      schedules: {
        ...prev.schedules,
        [day]: time
      }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name.trim()) {
      alert('학생 이름을 입력해주세요.');
      return;
    }
    if (Object.keys(formData.schedules).length === 0) {
      alert('등원 요일을 하나 이상 선택해주세요.');
      return;
    }

    let level = '초등부';
    if (formData.grade.startsWith('중')) level = '중등부';
    if (formData.grade.startsWith('고')) level = '고등부';

    addStudent({
      name: formData.name,
      school: formData.school,
      grade: formData.grade,
      phone: formData.phone,
      level,
      teacherId,
      schedules: formData.schedules
    });

    setFormData({
      name: '',
      school: '',
      grade: '초1',
      phone: '',
      schedules: {}
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-brand-50 px-6 py-4 flex justify-between items-center border-b border-brand-100">
          <div>
            <h2 className="text-xl font-bold text-gray-800">신규 학생 등록</h2>
            <p className="text-sm text-brand-600 mt-1">{teacher?.name} 선생님 ({teacher?.subject})</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white rounded-full transition-all text-gray-500 hover:text-gray-800">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2 custom-scrollbar">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">이름</label>
              <input
                type="text"
                value={formData.name}
                onChange={e => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400"
                placeholder="예: 홍길동"
              />
            </div>
            
            <div className="flex space-x-4">
              <div className="flex-1">
                <label className="block text-sm font-bold text-gray-700 mb-1">학교</label>
                <input
                  type="text"
                  value={formData.school}
                  onChange={e => setFormData({...formData, school: e.target.value})}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400"
                  placeholder="예: 에듀초등학교"
                />
              </div>
              <div className="w-1/3">
                <label className="block text-sm font-bold text-gray-700 mb-1">학년</label>
                <select
                  value={formData.grade}
                  onChange={e => setFormData({...formData, grade: e.target.value})}
                  className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 bg-white"
                >
                  {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">연락처</label>
              <input
                type="text"
                value={formData.phone}
                onChange={e => setFormData({...formData, phone: e.target.value})}
                className="w-full px-4 py-2 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400"
                placeholder="010-0000-0000"
              />
            </div>

            <div className="pt-2 border-t border-gray-100">
              <label className="block text-sm font-bold text-gray-700 mb-2">등원 요일 선택</label>
              <div className="flex space-x-1 justify-between mb-4">
                {DAYS.map(day => (
                  <button
                    key={day}
                    type="button"
                    onClick={() => toggleDay(day)}
                    className={`w-10 h-10 rounded-full font-bold text-sm transition-all flex items-center justify-center ${
                      formData.schedules[day] !== undefined
                        ? 'bg-brand-500 text-white shadow-md'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {day}
                  </button>
                ))}
              </div>
              
              {/* Selected Days Time Configurator */}
              {Object.keys(formData.schedules).length > 0 && (
                <div className="space-y-2 bg-gray-50 p-3 rounded-xl border border-gray-100">
                  <label className="block text-xs font-bold text-gray-500 mb-1">선택된 요일별 등원 시간 설정</label>
                  {DAYS.filter(day => formData.schedules[day] !== undefined).map(day => (
                    <div key={`time-${day}`} className="flex items-center justify-between">
                      <span className="font-bold text-brand-600 w-8">{day}요일</span>
                      <input
                        type="time"
                        value={formData.schedules[day]}
                        onChange={e => handleTimeChange(day, e.target.value)}
                        className="px-3 py-1.5 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 w-32 text-sm"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="pt-4 flex space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl font-bold transition-all"
            >
              취소
            </button>
            <button
              type="submit"
              className="flex-[2] px-4 py-3 bg-brand-500 hover:bg-brand-600 text-white rounded-xl font-bold transition-all shadow-md flex items-center justify-center"
            >
              <Check size={20} className="mr-1" /> 학생 등록
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
