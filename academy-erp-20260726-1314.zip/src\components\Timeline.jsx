import React from 'react';

export default function Timeline({ logs }) {
  if (!logs || logs.length === 0) {
    return <p className="text-center text-gray-400 py-8 text-sm">기록이 없습니다.</p>;
  }

  return (
    <div className="relative border-l-2 border-brand-200 ml-3 space-y-6">
      {logs.map(log => (
        <div key={log.id} className="relative pl-6">
          <div className="absolute w-4 h-4 bg-brand-400 rounded-full -left-[9px] top-1 border-4 border-white shadow-sm"></div>
          <div className="bg-brand-50 p-4 rounded-xl border border-brand-100 shadow-sm">
            <div className="flex justify-between items-start mb-2">
              <span className="font-bold text-gray-800 text-sm flex items-center">
                {log.type === 'consult' ? '📋 상담일지' : '📚 학습기록'}
                {log.studentName && <span className="ml-2 text-brand-600">[{log.studentName}]</span>}
              </span>
              <span className="text-xs text-gray-500">
                {log.timestamp ? new Date(log.timestamp).toLocaleString() : log.date}
              </span>
            </div>
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{log.content}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
