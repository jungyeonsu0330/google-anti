import { create } from 'zustand';
import { format } from 'date-fns';

const INITIAL_TEACHERS = [
  { id: 't1', name: '정연수', subject: '수학과', isClockedIn: false, clockInTime: null },
  { id: 't2', name: '정세은', subject: '수학과', isClockedIn: false, clockInTime: null },
  { id: 't3', name: '전창헌', subject: '수학과', isClockedIn: false, clockInTime: null },
  { id: 't4', name: '강소애', subject: '국어과', isClockedIn: false, clockInTime: null },
  { id: 't5', name: '김민정', subject: '국어과', isClockedIn: false, clockInTime: null },
  { id: 't6', name: '유재경', subject: '국어과', isClockedIn: false, clockInTime: null },
  { id: 't7', name: '유지원', subject: '국어과', isClockedIn: false, clockInTime: null },
  { id: 't8', name: '김혜림', subject: '영어과', isClockedIn: false, clockInTime: null },
  { id: 't9', name: '한규리', subject: '영어과', isClockedIn: false, clockInTime: null },
  { id: 't10', name: '민서현', subject: '영어과', isClockedIn: false, clockInTime: null },
  { id: 't11', name: '권동휘', subject: '아소비과', isClockedIn: false, clockInTime: null },
  { id: 't12', name: '이채원', subject: '아소비과', isClockedIn: false, clockInTime: null },
];

const INITIAL_STUDENTS = [
  // 초등부 (10)
  { id: 's1', name: '김초등', grade: '초1', level: '초등부', teacherId: 't1', school: '에듀초등학교', phone: '010-1111-1111' },
  { id: 's2', name: '이초등', grade: '초2', level: '초등부', teacherId: 't2', school: '에듀초등학교', phone: '010-2222-2222' },
  { id: 's3', name: '박초등', grade: '초3', level: '초등부', teacherId: 't3', school: '에듀초등학교', phone: '010-3333-3333' },
  { id: 's4', name: '최초등', grade: '초4', level: '초등부', teacherId: 't4', school: '에듀초등학교', phone: '010-4444-4444' },
  { id: 's5', name: '정초등', grade: '초5', level: '초등부', teacherId: 't5', school: '에듀초등학교', phone: '010-5555-5555' },
  { id: 's6', name: '강초등', grade: '초6', level: '초등부', teacherId: 't6', school: '에듀초등학교', phone: '010-6666-6666' },
  { id: 's7', name: '조초등', grade: '초3', level: '초등부', teacherId: 't7', school: '에듀초등학교', phone: '010-7777-7777' },
  { id: 's8', name: '윤초등', grade: '초4', level: '초등부', teacherId: 't8', school: '에듀초등학교', phone: '010-8888-8888' },
  { id: 's9', name: '장초등', grade: '초5', level: '초등부', teacherId: 't9', school: '에듀초등학교', phone: '010-9999-9999' },
  { id: 's10', name: '임초등', grade: '초6', level: '초등부', teacherId: 't1', school: '에듀초등학교', phone: '010-1010-1010' },
  // 중등부 (10)
  { id: 's11', name: '김중등', grade: '중1', level: '중등부', teacherId: 't2', school: '에듀중학교', phone: '010-1111-2222' },
  { id: 's12', name: '이중등', grade: '중2', level: '중등부', teacherId: 't3', school: '에듀중학교', phone: '010-2222-3333' },
  { id: 's13', name: '박중등', grade: '중3', level: '중등부', teacherId: 't4', school: '에듀중학교', phone: '010-3333-4444' },
  { id: 's14', name: '최중등', grade: '중1', level: '중등부', teacherId: 't5', school: '에듀중학교', phone: '010-4444-5555' },
  { id: 's15', name: '정중등', grade: '중2', level: '중등부', teacherId: 't6', school: '에듀중학교', phone: '010-5555-6666' },
  { id: 's16', name: '강중등', grade: '중3', level: '중등부', teacherId: 't7', school: '에듀중학교', phone: '010-6666-7777' },
  { id: 's17', name: '조중등', grade: '중1', level: '중등부', teacherId: 't8', school: '에듀중학교', phone: '010-7777-8888' },
  { id: 's18', name: '윤중등', grade: '중2', level: '중등부', teacherId: 't9', school: '에듀중학교', phone: '010-8888-9999' },
  { id: 's19', name: '장중등', grade: '중3', level: '중등부', teacherId: 't1', school: '에듀중학교', phone: '010-9999-0000' },
  { id: 's20', name: '임중등', grade: '중2', level: '중등부', teacherId: 't2', school: '에듀중학교', phone: '010-0000-1111' },
  // 고등부 (10)
  { id: 's21', name: '김고등', grade: '고1', level: '고등부', teacherId: 't3', school: '에듀고등학교', phone: '010-1212-1212' },
  { id: 's22', name: '이고등', grade: '고2', level: '고등부', teacherId: 't4', school: '에듀고등학교', phone: '010-2323-2323' },
  { id: 's23', name: '박고등', grade: '고3', level: '고등부', teacherId: 't5', school: '에듀고등학교', phone: '010-3434-3434' },
  { id: 's24', name: '최고등', grade: '고1', level: '고등부', teacherId: 't6', school: '에듀고등학교', phone: '010-4545-4545' },
  { id: 's25', name: '정고등', grade: '고2', level: '고등부', teacherId: 't7', school: '에듀고등학교', phone: '010-5656-5656' },
  { id: 's26', name: '강고등', grade: '고3', level: '고등부', teacherId: 't8', school: '에듀고등학교', phone: '010-6767-6767' },
  { id: 's27', name: '조고등', grade: '고1', level: '고등부', teacherId: 't9', school: '에듀고등학교', phone: '010-7878-7878' },
  { id: 's28', name: '윤고등', grade: '고2', level: '고등부', teacherId: 't1', school: '에듀고등학교', phone: '010-8989-8989' },
  { id: 's29', name: '장고등', grade: '고3', level: '고등부', teacherId: 't2', school: '에듀고등학교', phone: '010-9090-9090' },
  { id: 's30', name: '임고등', grade: '고3', level: '고등부', teacherId: 't3', school: '에듀고등학교', phone: '010-0101-0101' },
  { id: 's31', name: '안수현', grade: '고3', level: '고등부', teacherId: 't1', school: '다정고', phone: '010-2996-7921' },
  { id: 's32', name: '안예서', grade: '고2', level: '고등부', teacherId: 't1', school: '대성고', phone: '010-9761-1005' },
  { id: 's33', name: '정진영', grade: '고3', level: '고등부', teacherId: 't1', school: '다정고', phone: '010-9268-5625' },
  { id: 's34', name: '정하율', grade: '중1', level: '중등부', teacherId: 't1', school: '새움중', phone: '010-5936-0827' },
  { id: 's35', name: '최진우', grade: '고3', level: '고등부', teacherId: 't1', school: '다정고', phone: '010-9211-8321' },
  { id: 's36', name: '최호윤', grade: '고2', level: '고등부', teacherId: 't1', school: '대성고', phone: '010-7594-1399' },
  { id: 's37', name: '김민하', grade: '중3', level: '중등부', teacherId: 't1', school: '새움중', phone: '010-8494-4892' },
].map(s => ({ ...s, schedules: { '월': '14:00', '화': '14:00', '수': '14:00', '목': '14:00', '금': '14:00', '토': '14:00', '일': '14:00' }, attendance: {} }));

export const useStore = create((set) => ({
  currentUser: null, // null (not logged in), 'director' (김태완), or teacherId
  login: (userId, pin) => {
    if (userId === 'director' && pin === '1234') {
      set({ currentUser: 'director' });
      return true;
    }
    if (userId !== 'director' && pin === '1234') {
      set({ currentUser: userId });
      return true;
    }
    return false;
  },
  logout: () => set({ currentUser: null }),
  
  teachers: INITIAL_TEACHERS,
  students: INITIAL_STUDENTS,
  
  consultDrafts: {},
  updateConsultDraft: (studentId, text) => set((state) => ({
    consultDrafts: { ...state.consultDrafts, [studentId]: text }
  })),

  // { [dateKey]: { [studentId]: teacherId } }
  dailyClaims: {},
  claimStudent: (dateKey, studentId, teacherId) => set((state) => ({
    dailyClaims: {
      ...state.dailyClaims,
      [dateKey]: {
        ...(state.dailyClaims[dateKey] || {}),
        [studentId]: teacherId
      }
    }
  })),
  returnStudent: (dateKey, studentId) => set((state) => {
    const newDateClaims = { ...(state.dailyClaims[dateKey] || {}) };
    delete newDateClaims[studentId];
    return {
      dailyClaims: {
        ...state.dailyClaims,
        [dateKey]: newDateClaims
      }
    };
  }),

  addStudent: (student) => set((state) => ({
    students: [...state.students, { ...student, id: 's' + Date.now(), attendance: {} }]
  })),

  updateAttendance: (studentId, dateKey, status) => set((state) => ({
    students: state.students.map(s => 
      s.id === studentId 
        ? { ...s, attendance: { ...s.attendance, [dateKey]: status } }
        : s
    )
  })),
  
  clockIn: (teacherId) => set((state) => ({
    teachers: state.teachers.map(t => 
      t.id === teacherId 
        ? { ...t, isClockedIn: true, clockInTime: format(new Date(), 'yyyy-MM-dd HH:mm:ss') }
        : t
    )
  })),
  clockOut: (teacherId) => set((state) => ({
    teachers: state.teachers.map(t => 
      t.id === teacherId 
        ? { ...t, isClockedIn: false, clockInTime: null }
        : t
    )
  })),

  // 결재 항목들 (상담일지, 행정신청)
  // status: '대기', '승인', '반려', '상담요망'
  requests: [], 
  
  addRequest: (request) => set((state) => ({
    requests: [{ ...request, id: Date.now().toString(), timestamp: new Date(), status: '대기' }, ...state.requests]
  })),
  
  updateRequestStatus: (requestId, newStatus) => set((state) => ({
    requests: state.requests.map(req => 
      req.id === requestId ? { ...req, status: newStatus } : req
    )
  })),
  
  deleteRequest: (requestId) => set((state) => ({
    requests: state.requests.filter(req => req.id !== requestId)
  })),
  
  // 학습/상담 로그 타임라인
  learningLogs: [
    { id: 'l1', studentId: 's1', teacherId: 't1', date: '2026-07-24', content: '기초 연산 학습 완료. 덧셈 부분 오답 정리.', type: 'consult' }
  ],
  addLearningLog: (log) => set((state) => ({
    learningLogs: [{ ...log, id: Date.now().toString(), timestamp: new Date() }, ...state.learningLogs]
  })),
}));
