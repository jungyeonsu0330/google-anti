import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { LogIn } from 'lucide-react';

export default function Login() {
  const [selectedUser, setSelectedUser] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const { teachers, login } = useStore();

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');
    
    if (!selectedUser) {
      setError('이름을 선택해주세요.');
      return;
    }
    
    const success = login(selectedUser, pin);
    if (!success) {
      setError('비밀번호가 올바르지 않습니다. (기본 PIN: 1234)');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-50 relative overflow-hidden">
      {/* Decorative background circles */}
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-brand-200 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob"></div>
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-brand-300 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-[-20%] left-[20%] w-96 h-96 bg-brand-100 rounded-full mix-blend-multiply filter blur-3xl opacity-50 animate-blob animation-delay-4000"></div>

      <div className="bg-white/80 backdrop-blur-lg p-10 rounded-3xl shadow-xl w-full max-w-md z-10 border border-white">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-sm">
            <LogIn size={32} />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">에듀피아 ERP</h1>
          <p className="text-brand-600 font-medium mt-2">학원 통합 관리 시스템</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              이름 (아이디)
            </label>
            <select 
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition-all bg-white/50"
            >
              <option value="">이름을 선택하세요</option>
              <option value="director">김태완 (대표원장)</option>
              {teachers.map(t => (
                <option key={t.id} value={t.id}>{t.name} ({t.subject})</option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              비밀번호 (PIN)
            </label>
            <input 
              type="password" 
              placeholder="4자리 PIN 입력 (1234)"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition-all bg-white/50"
            />
          </div>

          {error && <p className="text-red-500 text-sm text-center font-medium animate-pulse">{error}</p>}

          <button 
            type="submit" 
            className="w-full bg-brand-500 hover:bg-brand-600 text-white font-bold py-3.5 px-4 rounded-xl transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
          >
            시스템 입장하기
          </button>
        </form>
      </div>
    </div>
  );
}
