import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { LogOut, Calendar, Users, CheckCircle, Clock, Search, ChevronRight, X } from 'lucide-react';
import CascadingFilter from '../components/CascadingFilter';
import Timeline from '../components/Timeline';

export default function DirectorDashboard() {
  const { teachers, students, requests, updateRequestStatus, learningLogs, logout } = useStore();
  
  // 필터 상태
  const [filterSubject, setFilterSubject] = useState('');
  const [filterTeacher, setFilterTeacher] = useState('');
  const [filterStudent, setFilterStudent] = useState('');
  
  const [approvalFilterSubject, setApprovalFilterSubject] = useState('');
  const [approvalFilterTeacher, setApprovalFilterTeacher] = useState('');
  
  const [selectedCalendarTeacher, setSelectedCalendarTeacher] = useState(null);
  
  const [selectedSubjectModal, setSelectedSubjectModal] = useState(null);

  const today = new Date();
  const dayString = ['일','월','화','수','목','금','토'][today.getDay()];
  const dateKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

  // 통합 타임라인 필터링 (학습 로그 + 상담/행정 요청)
  const allTimelineEvents = [
    ...learningLogs,
    ...requests.filter(req => req.type === 'consult').map(req => ({
      ...req,
      date: req.timestamp,
    }))
  ].sort((a, b) => new Date(b.timestamp || b.date) - new Date(a.timestamp || a.date));

  const filteredTimeline = allTimelineEvents.filter(event => {
    let match = true;
    if (filterSubject) {
      const teacher = teachers.find(t => t.id === event.teacherId);
      if (teacher?.subject !== filterSubject) match = false;
    }
    if (filterTeacher && event.teacherId !== filterTeacher) match = false;
    if (filterStudent && event.studentId !== filterStudent) match = false;
    return match;
  });

  const pendingRequests = requests.filter(req => {
    if (req.status !== '대기') return false;
    if (approvalFilterSubject) {
      const teacher = teachers.find(t => t.id === req.teacherId);
      if (teacher?.subject !== approvalFilterSubject) return false;
    }
    if (approvalFilterTeacher && req.teacherId !== approvalFilterTeacher) return false;
    return true;
  });

  // 출근 현황
  const clockedInTeachers = teachers.filter(t => t.isClockedIn);
  const clockedOutTeachers = teachers.filter(t => !t.isClockedIn);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm px-6 py-4 flex justify-between items-center sticky top-0 z-40">
        <div>
          <h1 className="text-xl font-bold text-gray-800">에듀피아 ERP - 대표원장 대시보드</h1>
          <p className="text-sm text-gray-500">김태완 원장님, 환영합니다.</p>
        </div>
        <button onClick={logout} className="p-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-600 transition-all">
          <LogOut size={20} />
        </button>
      </header>

      <main className="flex-1 p-6 max-w-screen-2xl mx-auto w-full grid grid-cols-12 gap-6">
        
        {/* Top: Filter & Integrated Timeline */}
        <div className="col-span-12">
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Search className="mr-2 text-brand-500" size={20}/> 
              다차원 통합 조회 (필터 및 연대기)
            </h2>
            <CascadingFilter 
              subject={filterSubject} setSubject={setFilterSubject}
              teacher={filterTeacher} setTeacher={setFilterTeacher}
              student={filterStudent} setStudent={setFilterStudent}
            />
            {/* Show Timeline if any filter is active */}
            {(filterSubject || filterTeacher || filterStudent) && (
              <div className="mt-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar bg-gray-50 p-4 rounded-xl border border-gray-100">
                <Timeline logs={filteredTimeline} />
              </div>
            )}
          </div>
        </div>

        {/* Left Column: Attendance & Today's Students */}
        <div className="col-span-12 lg:col-span-3 space-y-6">
          {/* 실시간 근태 모니터링 */}
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Users className="mr-2 text-brand-500" size={20}/> 
              실시간 근태 모니터링
            </h2>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-gray-500 mb-2">근무 중 ({clockedInTeachers.length}명)</h3>
                <div className="flex flex-wrap gap-2">
                  {clockedInTeachers.map(t => (
                    <span key={t.id} className="bg-green-100 text-green-700 px-3 py-1 rounded-lg text-sm font-bold flex items-center shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
                      {t.name}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-500 mb-2">출근 전 ({clockedOutTeachers.length}명)</h3>
                <div className="flex flex-wrap gap-2">
                  {clockedOutTeachers.map(t => (
                    <span key={t.id} className="bg-red-100 text-red-700 px-3 py-1 rounded-lg text-sm font-bold flex items-center shadow-sm">
                      <span className="w-2 h-2 rounded-full bg-red-500 mr-2"></span>
                      {t.name}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* 오늘 등원 학생 타임라인 (과목별 유동 인구) */}
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Clock className="mr-2 text-brand-500" size={20}/> 
              오늘 등원 현황
            </h2>
            <div className="space-y-4">
              {['수학과', '국어과', '영어과', '아소비과'].map(subj => {
                const subjTeachers = teachers.filter(t => t.subject === subj).map(t => t.id);
                const subjStudents = students.filter(s => subjTeachers.includes(s.teacherId));
                return (
                  <button 
                    key={subj} 
                    onClick={() => setSelectedSubjectModal(subj)}
                    className="w-full text-left bg-brand-50 hover:bg-brand-100 p-3 rounded-xl border border-brand-100 transition-all group"
                  >
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-bold text-brand-700 group-hover:text-brand-800">{subj}</span>
                      <span className="text-sm font-bold bg-white text-brand-600 px-2 py-0.5 rounded-full shadow-sm">{subjStudents.length}명</span>
                    </div>
                    <div className="text-xs flex flex-wrap gap-1 mt-1">
                      {subjStudents.map(s => {
                        const status = s.attendance?.[dateKey];
                        let color = 'text-gray-500 bg-gray-100/50';
                        if (status === '출석') color = 'text-green-700 font-bold bg-green-100/50';
                        if (status === '지각') color = 'text-blue-700 font-bold bg-blue-100/50';
                        if (status === '불참') color = 'text-red-700 font-bold bg-red-100/50';
                        return (
                          <span key={s.id} className={`px-1.5 py-0.5 rounded-md ${color}`}>
                            {s.name}
                          </span>
                        );
                      })}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Middle Column: Approval Center */}
        <div className="col-span-12 lg:col-span-5">
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5 h-full max-h-[70vh] flex flex-col">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center justify-between">
              <div className="flex items-center">
                <CheckCircle className="mr-2 text-brand-500" size={20}/> 
                실시간 결재 승인 센터
              </div>
              <span className="bg-red-100 text-red-600 px-2 py-1 rounded-lg text-xs font-bold">대기 {pendingRequests.length}건</span>
            </h2>
            
            <div className="mb-4">
              <CascadingFilter 
                subject={approvalFilterSubject} setSubject={setApprovalFilterSubject}
                teacher={approvalFilterTeacher} setTeacher={setApprovalFilterTeacher}
                hideStudent={true}
              />
            </div>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-4">
              {pendingRequests.length === 0 ? (
                <p className="text-center text-gray-400 py-8 text-sm">대기 중인 결재 건이 없습니다.</p>
              ) : (
                pendingRequests.map(req => {
                  const reqTeacher = teachers.find(t => t.id === req.teacherId);
                  return (
                    <div key={req.id} className="p-4 rounded-xl border border-gray-200 shadow-sm relative overflow-hidden group">
                      <div className="absolute top-0 left-0 w-1 h-full bg-brand-400"></div>
                      <div className="flex justify-between items-start mb-2 pl-2">
                        <div>
                          <span className="font-bold text-gray-800">{reqTeacher?.name} 선생님</span>
                          <span className="text-xs text-gray-500 ml-2">{new Date(req.timestamp).toLocaleTimeString()}</span>
                        </div>
                        <span className="text-xs font-bold px-2 py-1 rounded-md bg-gray-100 text-gray-600">
                          {req.type === 'consult' ? '상담일지' : `행정 (${req.adminType})`}
                        </span>
                      </div>
                      
                      {req.studentName && <div className="text-sm font-bold text-brand-600 pl-2 mb-1">학생: {req.studentName}</div>}
                      <p className="text-sm text-gray-700 pl-2 mb-4 whitespace-pre-wrap">{req.content}</p>
                      
                      <div className="flex space-x-2 pl-2">
                        <button onClick={() => updateRequestStatus(req.id, '승인완료')} className="flex-1 bg-green-500 hover:bg-green-600 text-white text-sm font-bold py-2 rounded-lg transition-all shadow-sm">승인완료</button>
                        <button onClick={() => updateRequestStatus(req.id, '상담요구')} className="flex-1 bg-red-500 hover:bg-red-600 text-white text-sm font-bold py-2 rounded-lg transition-all shadow-sm">상담요구</button>
                        <button onClick={() => updateRequestStatus(req.id, '반려')} className="flex-1 bg-gray-500 hover:bg-gray-600 text-white text-sm font-bold py-2 rounded-lg transition-all shadow-sm">반려</button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Calendar & Students */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Calendar className="mr-2 text-brand-500" size={20}/> 
              경영 달력
            </h2>
            <div className="bg-brand-50 rounded-xl p-4 min-h-[300px] flex flex-col">
              <div className="text-center font-bold text-lg mb-4">{new Date().getFullYear()}년 {new Date().getMonth() + 1}월</div>
              {/* 단순화된 달력 UI: 오늘 날짜에 출근한 강사 표시 */}
              <div className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex-1">
                <div className="font-bold text-gray-700 mb-2">오늘 ({new Date().getDate()}일) 근무자</div>
                <div className="space-y-2">
                  {clockedInTeachers.length === 0 ? (
                    <p className="text-sm text-gray-400">근무자가 없습니다.</p>
                  ) : (
                    clockedInTeachers.map(t => (
                      <button 
                        key={t.id}
                        onClick={() => setSelectedCalendarTeacher(t.id)}
                        className={`w-full text-left p-2 rounded-lg text-sm font-bold transition-all border ${selectedCalendarTeacher === t.id ? 'border-red-400 bg-red-50 text-red-600' : 'border-transparent text-red-500 hover:bg-gray-50'}`}
                      >
                        {t.name} ({t.subject})
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Calendar Clicked Teacher's Students */}
          {selectedCalendarTeacher && (
            <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5 animate-fade-in-up">
              <h2 className="text-md font-bold text-gray-800 mb-4">
                {teachers.find(t => t.id === selectedCalendarTeacher)?.name} 선생님 수강생
              </h2>
              <div className="max-h-[200px] overflow-y-auto pr-2 custom-scrollbar space-y-2">
                {students.filter(s => s.teacherId === selectedCalendarTeacher).map(student => (
                  <div key={student.id} className="flex justify-between items-center p-2 bg-gray-50 rounded-lg border border-gray-100">
                    <span className="font-bold text-sm">{student.name}</span>
                    <span className="text-xs bg-white border border-gray-200 px-2 py-1 rounded-md">{student.grade}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

      </main>

      {/* Subject Timeline Modal */}
      {selectedSubjectModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-2xl max-h-[80vh] flex flex-col shadow-2xl relative">
            <button 
              onClick={() => setSelectedSubjectModal(null)} 
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X size={24} />
            </button>
            
            <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
              <Clock className="mr-2 text-brand-500" />
              {selectedSubjectModal} 오늘({dayString}요일) 등원 타임라인
            </h2>
            
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
              {(() => {
                const subjTeachers = teachers.filter(t => t.subject === selectedSubjectModal).map(t => t.id);
                const subjStudents = students.filter(s => subjTeachers.includes(s.teacherId));
                const scheduledStudents = subjStudents.filter(s => s.schedules?.[dayString]);
                
                if (scheduledStudents.length === 0) {
                  return <p className="text-center text-gray-400 py-8">오늘 스케줄이 있는 학생이 없습니다.</p>;
                }

                // Group by time
                const timeGroups = {};
                scheduledStudents.forEach(s => {
                  const t = s.schedules[dayString];
                  if (!timeGroups[t]) timeGroups[t] = [];
                  timeGroups[t].push(s);
                });

                const sortedTimes = Object.keys(timeGroups).sort((a, b) => a.localeCompare(b));

                return (
                  <div className="relative border-l-2 border-brand-200 ml-3 space-y-6 pb-4">
                    {sortedTimes.map(time => (
                      <div key={time} className="relative pl-6">
                        <div className="absolute w-4 h-4 bg-brand-400 rounded-full -left-[9px] top-1 border-4 border-white shadow-sm"></div>
                        <div className="bg-brand-50 p-4 rounded-xl border border-brand-100 shadow-sm">
                          <h3 className="font-bold text-lg text-brand-700 mb-3">{time}</h3>
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {timeGroups[time].map(s => {
                              const status = s.attendance?.[dateKey];
                              let dotColor = 'bg-gray-300';
                              let statusText = '대기';
                              if (status === '출석') { dotColor = 'bg-green-500'; statusText = '출석'; }
                              if (status === '지각') { dotColor = 'bg-blue-500'; statusText = '지각'; }
                              if (status === '불참') { dotColor = 'bg-red-500'; statusText = '불참'; }

                              return (
                                <div key={s.id} className="bg-white p-2 rounded-lg border border-gray-100 flex items-center justify-between shadow-sm">
                                  <span className="font-bold text-gray-800 text-sm">{s.name}</span>
                                  <div className="flex items-center space-x-1">
                                    <span className={`w-2 h-2 rounded-full ${dotColor}`}></span>
                                    <span className="text-[10px] text-gray-500 font-bold">{statusText}</span>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
