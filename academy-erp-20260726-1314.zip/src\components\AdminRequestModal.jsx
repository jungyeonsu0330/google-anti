import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { X } from 'lucide-react';

export default function AdminRequestModal({ onClose, teacherId }) {
  const [type, setType] = useState('면담'); // 면담, 휴가, 급여, 학생상담
  const [content, setContent] = useState('');
  const { addRequest } = useStore();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!content.trim()) return;
    
    addRequest({
      teacherId,
      type: 'admin',
      adminType: type,
      content,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 w-full max-w-md shadow-2xl relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <X size={24} />
        </button>
        
        <h2 className="text-2xl font-bold text-gray-800 mb-6">원장님 신청</h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">분류</label>
            <div className="grid grid-cols-2 gap-2">
              {['면담', '휴가', '급여', '학생상담'].map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`py-2 px-4 rounded-xl border text-sm font-bold transition-all ${type === t ? 'bg-brand-50 border-brand-400 text-brand-700 shadow-sm' : 'border-gray-200 text-gray-600 hover:bg-gray-50'}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">신청 내용</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-400 focus:border-transparent transition-all min-h-[120px] resize-none"
              placeholder="상세 내용을 입력해주세요..."
            />
          </div>
          
          <button 
            type="submit" 
            className="w-full bg-brand-500 hover:bg-brand-600 text-white font-bold py-3 px-4 rounded-xl transition-all shadow-md mt-4"
          >
            승인 요청 (결재 올리기)
          </button>
        </form>
      </div>
    </div>
  );
}
