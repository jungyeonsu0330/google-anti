import React, { useState } from 'react';
import { useStore } from '../store/useStore';
import { LogOut, Clock, FileText, Send, UserSquare2, History, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { addDays, subDays } from 'date-fns';
import AdminRequestModal from '../components/AdminRequestModal';
import ConsultLogForm from '../components/ConsultLogForm';
import Timeline from '../components/Timeline';
import CascadingFilter from '../components/CascadingFilter';
import AddStudentModal from '../components/AddStudentModal';

export default function TeacherDashboard() {
  const { currentUser, teachers, students, logout, clockIn, clockOut, learningLogs, requests, updateAttendance, updateConsultDraft, consultDrafts, dailyClaims, claimStudent, returnStudent, addRequest } = useStore();
  const teacher = teachers.find(t => t.id === currentUser);
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('초등부'); // 초등부, 중등부, 고등부
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [currentDate, setCurrentDate] = useState(new Date());

  const days = ['일', '월', '화', '수', '목', '금', '토'];
  const formattedDate = `${currentDate.getFullYear()}. ${String(currentDate.getMonth() + 1).padStart(2, '0')}. ${String(currentDate.getDate()).padStart(2, '0')} (${days[currentDate.getDay()]})`;
  
  // 필터 상태
  const [filterSubject, setFilterSubject] = useState('');
  const [filterTeacher, setFilterTeacher] = useState('');
  const [filterStudent, setFilterStudent] = useState('');

  if (!teacher) return null;



  const myStudents = students.filter(s => {
    const studentTeacher = teachers.find(t => t.id === s.teacherId);
    return studentTeacher?.subject === teacher.subject && s.level === activeTab;
  });
  
  // 타임라인 필터링
  const filteredLogs = [
    ...learningLogs,
    ...requests
      .filter(req => req.type === 'consult' && req.status === '승인완료')
      .map(req => ({
        id: req.id,
        studentId: req.studentId,
        studentName: req.studentName,
        type: 'consult',
        content: req.content,
        timestamp: req.timestamp
      }))
  ]
  .filter(log => {
    let match = true;
    if (selectedStudent && log.studentId !== selectedStudent.id) match = false;
    return match;
  })
  .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const myRequests = requests.filter(req => req.teacherId === teacher.id);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm px-6 py-4 flex justify-between items-center sticky top-0 z-40">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 bg-brand-100 text-brand-600 rounded-full flex items-center justify-center">
            <UserSquare2 size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold text-gray-800">{teacher.name} 선생님</h1>
            <p className="text-sm text-gray-500">{teacher.subject}</p>
          </div>
          
          <div className="ml-8 flex items-center bg-gray-100 rounded-xl p-1 border border-gray-200">
            <button 
              onClick={() => setCurrentDate(prev => subDays(prev, 1))}
              className="p-1.5 rounded-lg hover:bg-white text-gray-500 hover:text-brand-600 transition-all hover:shadow-sm"
            >
              <ChevronLeft size={20} />
            </button>
            <div className="flex items-center px-4 font-bold text-gray-700 text-sm w-[180px] justify-center">
              <Calendar size={16} className="mr-2 text-brand-500" />
              {formattedDate}
            </div>
            <button 
              onClick={() => setCurrentDate(prev => addDays(prev, 1))}
              className="p-1.5 rounded-lg hover:bg-white text-gray-500 hover:text-brand-600 transition-all hover:shadow-sm"
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex space-x-2 bg-gray-100 p-1 rounded-xl">
            <button 
              onClick={() => clockIn(teacher.id)}
              disabled={teacher.isClockedIn}
              className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg font-bold transition-all text-sm ${teacher.isClockedIn ? 'bg-transparent text-gray-400 cursor-not-allowed shadow-none' : 'bg-green-500 hover:bg-green-600 text-white shadow-sm'}`}
            >
              <Clock size={16} />
              <span>출근</span>
            </button>
            <button 
              onClick={() => clockOut(teacher.id)}
              disabled={!teacher.isClockedIn}
              className={`flex items-center space-x-2 px-4 py-1.5 rounded-lg font-bold transition-all text-sm ${!teacher.isClockedIn ? 'bg-transparent text-gray-400 cursor-not-allowed shadow-none' : 'bg-red-500 hover:bg-red-600 text-white shadow-sm'}`}
            >
              <LogOut size={16} />
              <span>퇴근</span>
            </button>
          </div>
          
          <button onClick={() => setIsModalOpen(true)} className="flex items-center space-x-2 px-5 py-2.5 rounded-xl font-bold bg-brand-500 hover:bg-brand-600 text-white transition-all shadow-sm">
            <Send size={20} />
            <span>원장님 신청</span>
          </button>

          <button onClick={logout} className="p-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-600 transition-all">
            <LogOut size={20} />
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full grid grid-cols-12 gap-6">
        
        {/* Left Column: Students & Filter */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold text-gray-800 flex items-center">
                <FileText className="mr-2 text-brand-500" size={20}/> 
                나의 수강생
              </h2>
              <button 
                onClick={() => setIsAddStudentOpen(true)}
                className="text-xs font-bold bg-brand-50 hover:bg-brand-100 text-brand-600 px-3 py-1.5 rounded-lg transition-all border border-brand-200"
              >
                + 학생 추가
              </button>
            </div>
            
            {/* Tabs */}
            <div className="flex space-x-2 mb-4 bg-gray-100 p-1 rounded-xl">
              {['초등부', '중등부', '고등부'].map(tab => (
                <button
                  key={tab}
                  onClick={() => { setActiveTab(tab); setSelectedStudent(null); }}
                  className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${activeTab === tab ? 'bg-white text-brand-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                >
                  {tab}
                </button>
              ))}
            </div>

            {/* Student List */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
              {myStudents.length === 0 ? (
                <p className="text-center text-gray-400 py-8 text-sm">배정된 학생이 없습니다.</p>
              ) : (
                myStudents.map(student => {
                  const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth()+1).padStart(2,'0')}-${String(currentDate.getDate()).padStart(2,'0')}`;
                  const claimedBy = dailyClaims[dateKey]?.[student.id];
                  const isClaimedByMe = claimedBy === teacher.id;
                  const isClaimedByOther = claimedBy && claimedBy !== teacher.id;
                  const claimingTeacher = isClaimedByOther ? teachers.find(t => t.id === claimedBy) : null;

                  return (
                    <div
                      key={student.id}
                      onClick={() => setSelectedStudent(student)}
                      className={`w-full flex justify-between items-center text-left px-4 py-3 rounded-xl transition-all border cursor-pointer ${
                        selectedStudent?.id === student.id ? 'border-brand-400 bg-brand-50 text-brand-700' : 
                        isClaimedByOther ? 'border-transparent bg-gray-100 text-gray-400' : 
                        'border-transparent hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      <div>
                        <div className="font-bold flex items-center gap-2">
                          {student.name}
                          {isClaimedByMe && <span className="text-[10px] bg-brand-500 text-white px-1.5 py-0.5 rounded-md shadow-sm">내 수업</span>}
                          {isClaimedByOther && <span className="text-[10px] bg-gray-200 text-gray-500 px-1.5 py-0.5 rounded-md shadow-sm">{claimingTeacher?.name} 쌤 배정</span>}
                        </div>
                        <div className="text-xs opacity-70 flex items-center space-x-1 mt-1 flex-wrap gap-y-1">
                          <span>{student.grade}</span>
                          {student.school && (
                            <>
                              <span className="text-gray-300">|</span>
                              <span>{student.school}</span>
                            </>
                          )}
                          {student.phone && (
                            <>
                              <span className="text-gray-300">|</span>
                              <span>{student.phone}</span>
                            </>
                          )}
                        </div>
                      </div>
                      {!claimedBy && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            claimStudent(dateKey, student.id, teacher.id);
                          }}
                          className="text-xs font-bold bg-white border border-brand-200 text-brand-600 px-3 py-1.5 rounded-lg hover:bg-brand-50 transition-all shrink-0 shadow-sm"
                        >
                          선택
                        </button>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Today's Schedule Timeline */}
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <Clock className="mr-2 text-brand-500" size={20}/> 
              오늘 수업 일정
            </h2>
            <div className="relative border-l-2 border-brand-200 ml-3 space-y-4 pt-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {(() => {
                const dayString = days[currentDate.getDay()];
                const dateKey = `${currentDate.getFullYear()}-${String(currentDate.getMonth()+1).padStart(2,'0')}-${String(currentDate.getDate()).padStart(2,'0')}`;
                
                const scheduledStudents = students.filter(s => 
                  dailyClaims[dateKey]?.[s.id] === teacher.id
                ).sort((a, b) => (a.schedules?.[dayString] || '00:00').localeCompare(b.schedules?.[dayString] || '00:00'));

                if (scheduledStudents.length === 0) {
                  return <p className="text-center text-gray-400 text-sm py-4">오늘 수업 예정된 학생이 없습니다.</p>;
                }

                return scheduledStudents.map((student) => {
                  const status = student.attendance?.[dateKey];
                  let dotColor = 'bg-gray-300 border-white';
                  if (status === '출석') dotColor = 'bg-green-500 border-green-200';
                  if (status === '지각') dotColor = 'bg-blue-500 border-blue-200';
                  if (status === '불참') dotColor = 'bg-red-500 border-red-200';

                  const handleAttendance = (e, st) => {
                    e.stopPropagation();
                    updateAttendance(student.id, dateKey, st);
                    
                    const now = new Date();
                    const timeStr = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`;
                    const msg = `[${timeStr}] ${st} 처리됨.`;
                    
                    let currentDraft = consultDrafts[student.id] || '';
                    const dateHeader = `[${formattedDate}]\n`;
                    
                    if (!currentDraft.includes(`[${formattedDate}]`)) {
                      currentDraft = dateHeader + currentDraft;
                    }
                    
                    const newDraft = currentDraft + (currentDraft.endsWith('\n') ? '' : '\n') + msg + '\n';
                    
                    // 상담일지 입력란에만 기록 (보존)
                    updateConsultDraft(student.id, newDraft);
                  };

                  return (
                    <div key={`schedule-${student.id}`} className="relative pl-6 group">
                      <div className={`absolute w-3.5 h-3.5 rounded-full -left-[8px] top-1.5 border-2 shadow-sm transition-all ${dotColor}`}></div>
                      <div 
                        className={`p-3 rounded-xl border cursor-pointer transition-all ${selectedStudent?.id === student.id ? 'bg-brand-50 border-brand-300' : 'bg-gray-50 border-gray-100 hover:border-brand-200'}`}
                        onClick={() => { setActiveTab(student.level); setSelectedStudent(student); }}
                      >
                        <div className="flex justify-between items-center mb-2">
                          <span className="font-bold text-sm text-gray-800">{student.name}</span>
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-brand-600 bg-brand-100 px-2 py-0.5 rounded-full shadow-sm">
                              {student.schedules?.[dayString] || '미정'}
                            </span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                returnStudent(dateKey, student.id);
                              }}
                              className="text-[10px] font-bold text-gray-500 bg-gray-100 hover:bg-gray-200 px-2 py-0.5 rounded transition-all"
                            >
                              반환
                            </button>
                          </div>
                        </div>
                        
                        <div className="flex space-x-1 mt-2">
                          <button 
                            onClick={(e) => handleAttendance(e, '출석')}
                            className={`flex-1 text-[10px] font-bold py-1 rounded transition-all ${status === '출석' ? 'bg-green-500 text-white shadow-sm' : 'bg-gray-200 text-gray-600 hover:bg-green-100'}`}
                          >출석</button>
                          <button 
                            onClick={(e) => handleAttendance(e, '지각')}
                            className={`flex-1 text-[10px] font-bold py-1 rounded transition-all ${status === '지각' ? 'bg-blue-500 text-white shadow-sm' : 'bg-gray-200 text-gray-600 hover:bg-blue-100'}`}
                          >지각</button>
                          <button 
                            onClick={(e) => handleAttendance(e, '불참')}
                            className={`flex-1 text-[10px] font-bold py-1 rounded transition-all ${status === '불참' ? 'bg-red-500 text-white shadow-sm' : 'bg-gray-200 text-gray-600 hover:bg-red-100'}`}
                          >불참</button>
                        </div>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </div>
        </div>

        {/* Middle Column: Timeline & Consult Form */}
        <div className="col-span-12 lg:col-span-5 space-y-6 flex flex-col">
          {selectedStudent ? (
            <>
              <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5 flex-1 overflow-hidden flex flex-col">
                <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
                  <History className="mr-2 text-brand-500" size={20}/> 
                  {selectedStudent.name} 학생 상담일지 타임라인
                </h2>
                <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                  <Timeline logs={filteredLogs} />
                </div>
              </div>
              
              <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5">
                <h2 className="text-lg font-bold text-gray-800 mb-4">오늘의 상담일지 작성</h2>
                <ConsultLogForm student={selectedStudent} teacherId={teacher.id} />
              </div>
            </>
          ) : (
            <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5 h-full flex items-center justify-center text-gray-400 flex-col">
              <UserSquare2 size={48} className="mb-4 opacity-50" />
              <p>좌측에서 학생을 선택해주세요.</p>
            </div>
          )}
        </div>

        {/* Right Column: Approval Timeline */}
        <div className="col-span-12 lg:col-span-3">
          <div className="bg-white rounded-2xl shadow-sm border border-brand-100 p-5 h-full max-h-[85vh] flex flex-col">
            <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center">
              <FileText className="mr-2 text-brand-500" size={20}/> 
              나의 결재 타임라인
            </h2>
            <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-4">
              {myRequests.length === 0 ? (
                <p className="text-center text-gray-400 py-8 text-sm">신청 내역이 없습니다.</p>
              ) : (
                myRequests.map(req => (
                  <div key={req.id} className="p-4 rounded-xl border border-gray-100 bg-gray-50">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-sm font-bold text-gray-700">{req.type === 'consult' ? '상담일지' : `행정: ${req.adminType}`}</span>
                      <span className={`text-xs font-bold px-2 py-1 rounded-md ${req.status === '승인완료' ? 'bg-green-100 text-green-700' : req.status === '상담요구' ? 'bg-red-100 text-red-700' : req.status === '대기' ? 'bg-blue-100 text-blue-700' : 'bg-gray-200 text-gray-700'}`}>
                        {req.status}
                      </span>
                    </div>
                    {req.studentName && <div className="text-xs text-brand-600 mb-1">대상: {req.studentName}</div>}
                    <p className="text-sm text-gray-600 line-clamp-2">{req.content}</p>
                    <div className="text-xs text-gray-400 mt-2">{new Date(req.timestamp).toLocaleString()}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

      </main>

      {/* Admin Request Modal */}
      {isModalOpen && (
        <AdminRequestModal 
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        teacherId={teacher.id}
      />
      )}
      <AddStudentModal
        isOpen={isAddStudentOpen}
        onClose={() => setIsAddStudentOpen(false)}
        teacherId={teacher.id}
      />
    </div>
  );
}
