import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store/useStore';
import Login from './pages/Login';
import TeacherDashboard from './pages/TeacherDashboard';
import DirectorDashboard from './pages/DirectorDashboard';

function App() {
  const currentUser = useStore(state => state.currentUser);

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={!currentUser ? <Login /> : <Navigate to="/" replace />} />
        
        <Route path="/" element={
          !currentUser ? <Navigate to="/login" replace /> :
          currentUser === 'director' ? <DirectorDashboard /> : <TeacherDashboard />
        } />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
