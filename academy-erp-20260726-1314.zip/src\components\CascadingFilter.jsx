import React, { useMemo } from 'react';
import { useStore } from '../store/useStore';

export default function CascadingFilter({ subject, teacher, student, setSubject, setTeacher, setStudent, hideStudent = false }) {
  const { teachers, students } = useStore();

  const subjects = useMemo(() => {
    const subs = new Set(teachers.map(t => t.subject));
    return Array.from(subs);
  }, [teachers]);

  const filteredTeachers = useMemo(() => {
    return teachers.filter(t => !subject || t.subject === subject);
  }, [teachers, subject]);

  const filteredStudents = useMemo(() => {
    let list = students;
    if (teacher) {
      list = list.filter(s => s.teacherId === teacher);
    } else if (subject) {
      const subjectTeacherIds = teachers.filter(t => t.subject === subject).map(t => t.id);
      list = list.filter(s => subjectTeacherIds.includes(s.teacherId));
    }
    return list;
  }, [students, teachers, subject, teacher]);

  return (
    <div className="flex space-x-4 bg-white p-4 rounded-xl shadow-sm border border-brand-100">
      <select 
        value={subject} 
        onChange={(e) => { setSubject(e.target.value); setTeacher(''); setStudent(''); }}
        className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:ring-brand-400 focus:border-brand-400 text-sm"
      >
        <option value="">모든 과목</option>
        {subjects.map(s => <option key={s} value={s}>{s}</option>)}
      </select>

      <select 
        value={teacher} 
        onChange={(e) => { setTeacher(e.target.value); setStudent(''); }}
        className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:ring-brand-400 focus:border-brand-400 text-sm"
      >
        <option value="">모든 선생님</option>
        {filteredTeachers.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
      </select>

      {!hideStudent && (
        <select 
          value={student} 
          onChange={(e) => setStudent(e.target.value)}
          className="flex-1 px-3 py-2 rounded-lg border border-gray-200 focus:ring-brand-400 focus:border-brand-400 text-sm"
        >
          <option value="">모든 학생</option>
          {filteredStudents.map(s => <option key={s.id} value={s.id}>{s.name} ({s.grade})</option>)}
        </select>
      )}
    </div>
  );
}
